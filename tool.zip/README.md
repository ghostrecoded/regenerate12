# Content
ktp & kk Generate
# Contact you
zerosvn@merahputih.id
# Spesial Thanks
BabbyCyberTeam - SGB-TEAM - JNCK MEDIA.
# Command Install For Termux / Linux (pc)
```
Decoded by ./GhostRecoded_
www.ghostrecoded.zone.id

$ pkg install php
$ pkg install git
$ git clone https://github.com/zerosvn/regenerate12
$ cd regenerate
$ ls
$ php kuylah.php
```
# Have Fun Dear :*
